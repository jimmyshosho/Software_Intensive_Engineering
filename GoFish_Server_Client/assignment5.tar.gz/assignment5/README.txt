The provided code is the concurrent echo client and server from class. You can use this code to build your chat client and server.

Provide a summary of your code, your solution approach, and any problems you encountered and how you addressed them.  You should also state any problems with the code, and if its usage differs in anyway from the specification above.  Also, if you worked with a partner, make sure to state your partner. Note that everyone must turn in their code. 


